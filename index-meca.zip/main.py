def main():
    print("Hello from intro-datasci-vscode!")


if __name__ == "__main__":
    main()
